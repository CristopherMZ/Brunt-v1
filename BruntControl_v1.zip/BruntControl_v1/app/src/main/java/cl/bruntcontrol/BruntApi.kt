package cl.bruntcontrol

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection

class BruntApi {
    private val accept = "application/vnd.brunt.v1+json"
    private val userAgent =
        "Mozilla/5.0 (iPhone; CPU iPhone OS 11_3 like Mac OS X) " +
        "AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E216"

    fun login(username: String, password: String): BruntLogin {
        val json = JSONObject().put("ID", username).put("PASS", password).toString()
        val c = connection("https://sky.brunt.co/session", "POST", json, null)
        val response = JSONObject(read(c))
        if (response.optString("status") != "activate") error("Login rechazado por Brunt")

        val session = c.headerFields["Set-Cookie"]
            ?.asSequence()?.flatten()
            ?.flatMap { it.split(";").asSequence() }
            ?.map { it.trim() }
            ?.firstOrNull { it.startsWith("skySSEIONID=") }
            ?.substringAfter("=")
            ?: response.optString("sessionId").takeIf { it.isNotBlank() }
            ?: error("Brunt no devolvió una sesión")

        return BruntLogin(response.optString("nickname", username), session)
    }

    fun getThings(sessionId: String): List<BruntThing> {
        val c = connection("https://sky.brunt.co/thing", "GET", null, sessionId)
        val a = JSONArray(read(c))
        return (0 until a.length()).map { i ->
            val j = a.getJSONObject(i)
            BruntThing(
                name = j.optString("NAME", "Cortina"),
                serial = j.optString("SERIAL"),
                model = j.optString("MODEL"),
                currentPosition = j.optString("currentPosition", "0").toIntOrNull() ?: 0,
                thingUri = j.optString("thingUri")
            )
        }
    }

    fun getState(sessionId: String, thingUri: String): BruntThing {
        val c = connection("https://thing.brunt.co:8080/thing$thingUri", "GET", null, sessionId)
        val j = JSONObject(read(c))
        return BruntThing(
            name = j.optString("NAME", "Cortina"),
            serial = j.optString("SERIAL"),
            model = j.optString("MODEL"),
            currentPosition = j.optString("currentPosition", "0").toIntOrNull() ?: 0,
            thingUri = thingUri
        )
    }

    fun changePosition(sessionId: String, thingUri: String, position: Int) {
        require(position in 0..100)
        val body = JSONObject().put("requestPosition", position.toString()).toString()
        val c = connection("https://thing.brunt.co:8080/thing$thingUri", "PUT", body, sessionId)
        read(c)
    }

    private fun connection(url: String, method: String, body: String?, sid: String?): HttpsURLConnection {
        val c = URL(url).openConnection() as HttpsURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Accept", accept)
        c.setRequestProperty("Accept-Language", "en-gb")
        c.setRequestProperty("User-Agent", userAgent)
        sid?.let { c.setRequestProperty("Cookie", "skySSEIONID=$it") }

        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            c.setRequestProperty("Origin", "https://sky.brunt.co")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        return c
    }

    private fun read(c: HttpsURLConnection): String {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else (c.errorStream ?: c.inputStream)
        val text = BufferedReader(InputStreamReader(stream)).use { it.readText() }
        if (code !in 200..299) error("Brunt HTTP $code: ${text.take(250)}")
        return text
    }
}
