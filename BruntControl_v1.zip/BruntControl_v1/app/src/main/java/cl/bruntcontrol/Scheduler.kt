package cl.bruntcontrol

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object Scheduler {
    fun schedule(context: Context, rule: ScheduleRule) {
        cancel(context, rule.id)
        if (!rule.enabled) return

        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val trigger = nextTrigger(rule)
        val pi = pendingIntent(context, rule)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        } else {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    fun cancel(context: Context, id: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ScheduleReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            id.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) alarm.cancel(pi)
    }

    fun rescheduleAll(context: Context) {
        ScheduleStore(context).all().filter { it.enabled }.forEach { schedule(context, it) }
    }

    private fun pendingIntent(context: Context, rule: ScheduleRule): PendingIntent {
        val i = Intent(context, ScheduleReceiver::class.java).apply {
            putExtra("ruleId", rule.id)
        }
        return PendingIntent.getBroadcast(
            context,
            rule.id.toInt(),
            i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun nextTrigger(rule: ScheduleRule): Long {
        val now = Calendar.getInstance()
        for (offset in 0..7) {
            val c = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, offset)
                set(Calendar.HOUR_OF_DAY, rule.hour)
                set(Calendar.MINUTE, rule.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (rule.appliesToCalendarDay(c.get(Calendar.DAY_OF_WEEK)) && c.timeInMillis > now.timeInMillis) {
                return c.timeInMillis
            }
        }
        return now.timeInMillis + 24 * 60 * 60 * 1000L
    }
}
