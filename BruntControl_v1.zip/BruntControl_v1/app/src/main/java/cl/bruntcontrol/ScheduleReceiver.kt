package cl.bruntcontrol

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.concurrent.Executors

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val ruleId = intent.getLongExtra("ruleId", -1L)
        Executors.newSingleThreadExecutor().execute {
            try {
                val rule = ScheduleStore(context).all().firstOrNull { it.id == ruleId } ?: return@execute
                val credentials = CredentialStore(context).load() ?: return@execute
                val api = BruntApi()
                val login = api.login(credentials.first, credentials.second)
                api.changePosition(login.sessionId, rule.thingUri, rule.position)
                Scheduler.schedule(context, rule)
            } finally {
                pending.finish()
            }
        }
    }
}
