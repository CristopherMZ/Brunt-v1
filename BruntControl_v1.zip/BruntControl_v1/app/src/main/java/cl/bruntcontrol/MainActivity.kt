package cl.bruntcontrol

import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { BruntApp() } }
    }
}

@Composable
private fun BruntApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { BruntApi() }
    val credentialStore = remember { CredentialStore(context) }
    val scheduleStore = remember { ScheduleStore(context) }

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var sessionId by remember { mutableStateOf<String?>(null) }
    var nickname by remember { mutableStateOf("") }
    var things by remember { mutableStateOf<List<BruntThing>>(emptyList()) }
    var schedules by remember { mutableStateOf(scheduleStore.all()) }
    var status by remember { mutableStateOf("Ingresa tus credenciales Brunt.") }
    var busy by remember { mutableStateOf(false) }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Brunt Control", style = MaterialTheme.typography.headlineLarge)
            Text("Control y programación horaria para Brunt Blind Engine")

            if (sessionId == null) {
                OutlinedTextField(username, { username = it }, label = { Text("Usuario / correo") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    password, { password = it },
                    label = { Text("Contraseña") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    enabled = !busy && username.isNotBlank() && password.isNotBlank(),
                    onClick = {
                        busy = true
                        scope.launch {
                            runCatching {
                                withContext(Dispatchers.IO) {
                                    val login = api.login(username.trim(), password)
                                    val devices = api.getThings(login.sessionId)
                                    Triple(login, devices, Unit)
                                }
                            }.onSuccess { (login, devices, _) ->
                                credentialStore.save(username.trim(), password)
                                nickname = login.nickname
                                sessionId = login.sessionId
                                things = devices
                                password = ""
                                status = "Conectado como $nickname"
                            }.onFailure {
                                status = it.message ?: "Error de conexión"
                            }
                            busy = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "Conectando…" else "CONECTAR") }
            } else {
                Text(status, style = MaterialTheme.typography.titleMedium)
                things.forEach { thing ->
                    DeviceCard(
                        thing = thing,
                        onMove = { pos ->
                            scope.launch {
                                status = "Moviendo ${thing.name}…"
                                runCatching {
                                    withContext(Dispatchers.IO) {
                                        api.changePosition(sessionId!!, thing.thingUri, pos)
                                    }
                                }.onSuccess { status = "${thing.name}: orden $pos% enviada" }
                                 .onFailure { status = it.message ?: "Error al mover" }
                            }
                        },
                        onAddSchedule = { hour, minute, pos, daysMask ->
                            val rule = ScheduleRule(
                                id = System.currentTimeMillis(),
                                thingName = thing.name,
                                thingUri = thing.thingUri,
                                hour = hour,
                                minute = minute,
                                position = pos,
                                daysMask = daysMask
                            )
                            scheduleStore.save(rule)
                            Scheduler.schedule(context, rule)
                            schedules = scheduleStore.all()
                        }
                    )
                }

                HorizontalDivider()
                Text("Programaciones", style = MaterialTheme.typography.headlineSmall)
                ExactAlarmPermissionCard()

                if (schedules.isEmpty()) {
                    Text("Todavía no hay horarios programados.")
                } else {
                    schedules.forEach { r ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(r.thingName, style = MaterialTheme.typography.titleMedium)
                                    Text("%02d:%02d  •  %d%%".format(r.hour, r.minute, r.position))
                                    Text(daysText(r.daysMask))
                                }
                                TextButton(onClick = {
                                    Scheduler.cancel(context, r.id)
                                    scheduleStore.delete(r.id)
                                    schedules = scheduleStore.all()
                                }) { Text("Eliminar") }
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = {
                        credentialStore.clear()
                        sessionId = null
                        things = emptyList()
                        status = "Sesión cerrada."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Cerrar sesión y borrar credenciales") }
            }

            Text(status, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun DeviceCard(
    thing: BruntThing,
    onMove: (Int) -> Unit,
    onAddSchedule: (Int, Int, Int, Int) -> Unit
) {
    var pos by remember(thing.thingUri) { mutableFloatStateOf(thing.currentPosition.toFloat()) }
    var showSchedule by remember { mutableStateOf(false) }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(thing.name, style = MaterialTheme.typography.headlineSmall)
            if (thing.model.isNotBlank()) Text(thing.model, style = MaterialTheme.typography.bodySmall)
            Text("${pos.toInt()}%")
            Slider(pos, { pos = it }, valueRange = 0f..100f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ pos = 0f; onMove(0) }, Modifier.weight(1f)) { Text("Cerrar") }
                Button({ pos = 50f; onMove(50) }, Modifier.weight(1f)) { Text("50%") }
                Button({ pos = 100f; onMove(100) }, Modifier.weight(1f)) { Text("Abrir") }
            }
            FilledTonalButton({ onMove(pos.toInt()) }, Modifier.fillMaxWidth()) {
                Text("Mover a ${pos.toInt()}%")
            }
            OutlinedButton({ showSchedule = true }, Modifier.fillMaxWidth()) {
                Text("＋ Programar horario")
            }
        }
    }

    if (showSchedule) {
        ScheduleDialog(
            thingName = thing.name,
            defaultPosition = pos.toInt(),
            onDismiss = { showSchedule = false },
            onSave = { h, m, p, mask ->
                onAddSchedule(h, m, p, mask)
                showSchedule = false
            }
        )
    }
}

@Composable
private fun ScheduleDialog(
    thingName: String,
    defaultPosition: Int,
    onDismiss: () -> Unit,
    onSave: (Int, Int, Int, Int) -> Unit
) {
    val now = Calendar.getInstance()
    var hourText by remember { mutableStateOf(now.get(Calendar.HOUR_OF_DAY).toString()) }
    var minuteText by remember { mutableStateOf(now.get(Calendar.MINUTE).toString()) }
    var position by remember { mutableFloatStateOf(defaultPosition.toFloat()) }
    var mask by remember { mutableIntStateOf(0b1111111) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Programar $thingName") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(hourText, { hourText = it.filter(Char::isDigit).take(2) }, label = { Text("Hora") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(minuteText, { minuteText = it.filter(Char::isDigit).take(2) }, label = { Text("Min") }, modifier = Modifier.weight(1f))
                }
                Text("Posición: ${position.toInt()}%")
                Slider(position, { position = it }, valueRange = 0f..100f)
                Text("Días")
                val names = listOf("L","M","X","J","V","S","D")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    names.forEachIndexed { i, name ->
                        FilterChip(
                            selected = (mask and (1 shl i)) != 0,
                            onClick = {
                                mask = if ((mask and (1 shl i)) != 0) mask and (1 shl i).inv()
                                else mask or (1 shl i)
                            },
                            label = { Text(name) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val h = hourText.toIntOrNull()?.coerceIn(0,23) ?: 0
                val m = minuteText.toIntOrNull()?.coerceIn(0,59) ?: 0
                if (mask != 0) onSave(h, m, position.toInt(), mask)
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun ExactAlarmPermissionCard() {
    val context = androidx.compose.ui.platform.LocalContext.current
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val alarm = context.getSystemService(AlarmManager::class.java)
        val exact = alarm.canScheduleExactAlarms()
        if (!exact) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Horarios exactos", style = MaterialTheme.typography.titleMedium)
                    Text("Android puede retrasar horarios si no autorizas “Alarmas y recordatorios”.")
                    Button(onClick = {
                        val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        context.startActivity(i)
                    }) { Text("Autorizar horarios exactos") }
                }
            }
        }
    }
}

private fun daysText(mask: Int): String {
    val n = listOf("L","M","X","J","V","S","D")
    return n.mapIndexedNotNull { i, s -> s.takeIf { (mask and (1 shl i)) != 0 } }.joinToString(" ")
}
