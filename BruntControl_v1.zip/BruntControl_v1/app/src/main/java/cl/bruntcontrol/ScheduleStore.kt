package cl.bruntcontrol

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ScheduleStore(context: Context) {
    private val prefs = context.getSharedPreferences("brunt_schedules", Context.MODE_PRIVATE)

    fun all(): List<ScheduleRule> {
        val raw = prefs.getString("rules", "[]") ?: "[]"
        val a = JSONArray(raw)
        return (0 until a.length()).map { i ->
            val j = a.getJSONObject(i)
            ScheduleRule(
                id = j.getLong("id"),
                thingName = j.getString("thingName"),
                thingUri = j.getString("thingUri"),
                hour = j.getInt("hour"),
                minute = j.getInt("minute"),
                position = j.getInt("position"),
                daysMask = j.getInt("daysMask"),
                enabled = j.optBoolean("enabled", true)
            )
        }
    }

    fun save(rule: ScheduleRule) {
        val rules = all().filterNot { it.id == rule.id } + rule
        write(rules.sortedBy { it.hour * 60 + it.minute })
    }

    fun delete(id: Long) = write(all().filterNot { it.id == id })

    private fun write(rules: List<ScheduleRule>) {
        val a = JSONArray()
        rules.forEach { r ->
            a.put(JSONObject()
                .put("id", r.id)
                .put("thingName", r.thingName)
                .put("thingUri", r.thingUri)
                .put("hour", r.hour)
                .put("minute", r.minute)
                .put("position", r.position)
                .put("daysMask", r.daysMask)
                .put("enabled", r.enabled))
        }
        prefs.edit().putString("rules", a.toString()).apply()
    }
}
