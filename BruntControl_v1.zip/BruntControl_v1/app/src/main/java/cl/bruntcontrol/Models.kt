package cl.bruntcontrol

data class BruntLogin(
    val nickname: String,
    val sessionId: String
)

data class BruntThing(
    val name: String,
    val serial: String,
    val model: String,
    val currentPosition: Int,
    val thingUri: String
)

data class ScheduleRule(
    val id: Long,
    val thingName: String,
    val thingUri: String,
    val hour: Int,
    val minute: Int,
    val position: Int,
    val daysMask: Int,
    val enabled: Boolean = true
) {
    fun appliesToCalendarDay(calendarDay: Int): Boolean {
        val bit = when (calendarDay) {
            java.util.Calendar.MONDAY -> 0
            java.util.Calendar.TUESDAY -> 1
            java.util.Calendar.WEDNESDAY -> 2
            java.util.Calendar.THURSDAY -> 3
            java.util.Calendar.FRIDAY -> 4
            java.util.Calendar.SATURDAY -> 5
            java.util.Calendar.SUNDAY -> 6
            else -> return false
        }
        return (daysMask and (1 shl bit)) != 0
    }
}
