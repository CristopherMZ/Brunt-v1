# Brunt Control v1

App Android exclusiva para Brunt Blind Engine.

## Incluye
- Login Brunt.
- Detección de cortinas.
- Abrir, cerrar, 50% y porcentaje libre.
- Programación horaria por cortina.
- Días de la semana.
- Posición 0–100%.
- Reprogramación después de reiniciar el teléfono.
- Credenciales cifradas con Android Keystore para permitir ejecuciones programadas.
- Solicitud de permiso de alarmas exactas cuando Android lo requiere.

## API
Replica el comportamiento del proyecto archivado `AmyJeanes/brunt-api`:
- POST `https://sky.brunt.co/session`
- GET `https://sky.brunt.co/thing`
- GET/PUT `https://thing.brunt.co:8080/thing{thingUri}`
- Cookie de sesión: `skySSEIONID`

La API es no oficial y puede cambiar.

## Compilación en GitHub
El ZIP contiene `.github/workflows/android.yml`.

Si subes los archivos descomprimidos al repositorio:
Actions → Build Brunt Android APK → Run workflow.

Si prefieres subir este ZIP tal cual, usa un workflow externo que lo descomprima antes de ejecutar Gradle.
